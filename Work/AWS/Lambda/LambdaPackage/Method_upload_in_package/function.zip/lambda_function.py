import json
import urllib3


def lambda_handler(event, context):
    http = urllib3.PoolManager()
    response = http.request('GET','api-xmnup.lab.nordigy.ru/restapi/v1.0/account/~',headers = {'Content-Type': 'application/json'})
    # response = http.request('GET','www.baidu.com',headers = {'Content-Type': 'application/json'})
    print(response.status)
    return response.status
    #response.data.decode()