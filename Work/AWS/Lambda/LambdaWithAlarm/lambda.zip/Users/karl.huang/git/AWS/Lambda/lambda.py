import os

def lambda_handler(event,context):
    Word = os.environ['Word']
    print("Hello" + Word)
    Print("event")
    print(event)